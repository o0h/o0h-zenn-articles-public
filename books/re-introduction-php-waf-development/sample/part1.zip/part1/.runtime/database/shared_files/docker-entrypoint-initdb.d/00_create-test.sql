create database test;
GRANT ALL PRIVILEGES ON *.* TO 'app_user';